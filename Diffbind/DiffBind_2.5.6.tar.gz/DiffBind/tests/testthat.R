library(testthat)
library(DiffBind)

test_check("DiffBind")
